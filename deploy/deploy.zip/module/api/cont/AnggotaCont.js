"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnggotaCont = void 0;
class AnggotaCont {
}
exports.AnggotaCont = AnggotaCont;
