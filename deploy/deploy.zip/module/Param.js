"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Param = void 0;
class Param {
    static HA_DLG = "ha-dlg";
    static HA_KLIK = "ha-klik";
    static HA_URL = "ha-url";
    static HA_KF = 'ha-kf';
    static HA_GET = 'ha-get';
    static HA_POST = 'ha-post';
    static HA_RELOAD = 'ha-onpost-reload';
    static HA_MD5 = 'ha-md5';
    static HA_TINYMCE = 'ha-tinymce';
    static HA_REF = 'ha-ref';
    static HA_SIMPAN_REF = 'ha-simpan-ref';
    static HA_RP = 'ha-rp';
    static HA_TOGGLE = 'ha-toggle';
    static HA_MANUAL = 'ha-manual';
}
exports.Param = Param;
