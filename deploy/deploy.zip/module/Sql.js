"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sql = void 0;
const Connection_1 = require("./Connection");
class Sql {
    async query(query, data) {
        this.log(query, data);
        return new Promise((resolve, reject) => {
            Connection_1.Connection.pool.query(query, data, (_err, _rows) => {
                if (_err) {
                    reject(_err);
                }
                else {
                    resolve(_rows);
                    // console.debug(_rows);
                }
            });
        });
    }
    log(query, data) {
        query = query.replace(/\t/g, '');
        console.log("=============");
        console.log('query:');
        console.debug(query);
        console.log("data:");
        console.log(data);
        console.log("=============");
    }
}
exports.sql = new Sql();
