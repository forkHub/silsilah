"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Web = void 0;
const Profile_1 = require("./Profile");
class Web {
    profile = new Profile_1.Profile();
}
exports.Web = Web;
