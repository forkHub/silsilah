"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnggotaEnt = void 0;
class AnggotaEnt {
    async muat(id) {
        id; //TODO:
        return null; //TODO:
    }
}
exports.AnggotaEnt = AnggotaEnt;
