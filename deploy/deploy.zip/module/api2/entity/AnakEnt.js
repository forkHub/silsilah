"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnakEnt = void 0;
const Dao_1 = require("../dao/Dao");
class AnakEnt {
    async daftar(ortuId, kunci, hal) {
        Dao_1.dao.anak.daftarAnak(ortuId, kunci, hal);
        return [];
    }
}
exports.AnakEnt = AnakEnt;
