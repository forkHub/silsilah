"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ent = void 0;
const AnakEnt_1 = require("./AnakEnt");
const AnggotaEnt_1 = require("./AnggotaEnt");
const PasanganEnt_1 = require("./PasanganEnt");
class Entity {
    anak = new AnakEnt_1.AnakEnt();
    anggota = new AnggotaEnt_1.AnggotaEnt();
    pasangan = new PasanganEnt_1.PasanganEnt();
}
exports.ent = new Entity();
