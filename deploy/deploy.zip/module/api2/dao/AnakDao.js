"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnakDao = void 0;
const Sql_1 = require("../../Sql");
class AnakDao {
    async daftarAnak(rel_id, kunci, hal) {
        let hasil;
        if (kunci == "") {
            if (hal == 0) {
                hasil == await Sql_1.sql.query(`SELECT *
					FROM sl_anggota
					WHERE ortu_id = ?
					ORDER BY tgl_lahir`, [rel_id]);
            }
            else if (hal > 0) {
                //TODO:
            }
            else {
            }
        }
        else if (kunci != '') {
            if (hal == 0) {
            }
            else if (hal > 0) {
            }
            else {
            }
        }
        return hasil;
    }
}
exports.AnakDao = AnakDao;
