"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.queryObj = void 0;
class Query {
    selectAnggota = `			
            SELECT *
			FROM sl_anggota
    `;
}
exports.queryObj = new Query();
