"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dao = void 0;
// import { Anggota } from "../../silsilah/ent/Anggota";
const AnakDao_1 = require("./AnakDao");
const AnggotaDao_1 = require("./AnggotaDao");
class Dao {
    anak = new AnakDao_1.AnakDao();
    anggota = new AnggotaDao_1.AnggotaDao();
}
exports.dao = new Dao();
