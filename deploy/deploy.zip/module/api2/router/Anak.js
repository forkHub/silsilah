"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnakCont = void 0;
const Mid_1 = require("../mid/Mid");
const RouterAPI2Kons_1 = require("../RouterAPI2Kons");
class AnakCont {
    mapRouter(router) {
        router.post(RouterAPI2Kons_1.RouterAPI2Kons.api_anggota_daftar, Mid_1.mid.authMid.checkAuthSession, (_req, _resp) => {
            //TODO:
        });
    }
}
exports.AnakCont = AnakCont;
