"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.api2 = void 0;
const Router_1 = require("./router/Router");
class Api2 {
    router = new Router_1.Router();
}
exports.api2 = new Api2();
