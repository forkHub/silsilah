"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnakCont = void 0;
const Entity_1 = require("../entity/Entity");
class AnakCont {
    async daftar(ortuId, kunci, hal) {
        let daftar = {
            daftar: [],
            hal: 0,
            kunci: ''
        };
        daftar.daftar = await Entity_1.ent.anak.daftar(ortuId, kunci, hal);
        return daftar;
    }
}
exports.AnakCont = AnakCont;
